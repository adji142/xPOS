<!DOCTYPE html>
<html>
<head>
    <title>Email Konfirmasi</title>
</head>
<body>
    <h1>{{ $data['title'] }}</h1>
    <p>{{ $data['message'] }}</p>
</body>
</html>