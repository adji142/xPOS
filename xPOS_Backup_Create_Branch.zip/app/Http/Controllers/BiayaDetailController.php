<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BiayaDetailController extends Controller
{
    //
}
