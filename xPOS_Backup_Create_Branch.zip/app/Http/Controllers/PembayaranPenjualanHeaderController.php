<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PembayaranPenjualanHeaderController extends Controller
{
    //
}
