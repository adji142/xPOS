<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PengakuanBarangDetailController extends Controller
{
    //
}
