<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FakturPenjualanDetailController extends Controller
{
    //
}
