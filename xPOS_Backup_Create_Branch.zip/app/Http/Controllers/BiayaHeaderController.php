<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BiayaHeaderController extends Controller
{
    //
}
