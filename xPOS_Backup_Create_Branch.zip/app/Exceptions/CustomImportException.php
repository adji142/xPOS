<?php 
// app/Exceptions/CustomImportException.php
namespace App\Exceptions;

use Exception;

class CustomImportException extends Exception
{
    //
}
?>