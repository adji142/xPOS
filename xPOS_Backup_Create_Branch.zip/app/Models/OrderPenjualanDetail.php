<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderPenjualanDetail extends BaseModel
{
    use HasFactory;
    protected $table = 'orderpenjualandetail';
}
