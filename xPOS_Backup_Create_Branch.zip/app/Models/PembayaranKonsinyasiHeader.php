<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PembayaranKonsinyasiHeader extends BaseModel
{
    use HasFactory;
    protected $table = "pembayarankonsinyasiheader";
}
